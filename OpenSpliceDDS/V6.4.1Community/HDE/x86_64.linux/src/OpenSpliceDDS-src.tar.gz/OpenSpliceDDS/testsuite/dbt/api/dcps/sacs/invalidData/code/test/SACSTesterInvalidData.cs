
using test.sacs;

/**
 * 
 * 
 * @date May 24, 2005 
 */
namespace test
{    
    public class SACSTesterInvalidData 
    {
    
        public static void Main(string[] args)  
        {
            InvalidData invalidDataTest = new InvalidData();
            invalidDataTest.runAll();
        }
    }
}
