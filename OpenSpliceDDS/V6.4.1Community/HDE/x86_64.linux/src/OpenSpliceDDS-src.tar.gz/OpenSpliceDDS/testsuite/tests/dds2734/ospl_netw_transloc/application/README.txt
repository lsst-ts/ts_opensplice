To build application follow steps.

On Linux
----------

1. open terminal
2. set the OpenSpliceDDS environment variables (release.com script supplied with the distribution)
2. type make

On Windows
----------
1. set the OpenSpliceDDS environment variables (release.com script supplied with the distribution)
2. build VS2008 solution this_folder\Transloc\Transloc.sln

Executed files will be generated in this_folder\exec folder.