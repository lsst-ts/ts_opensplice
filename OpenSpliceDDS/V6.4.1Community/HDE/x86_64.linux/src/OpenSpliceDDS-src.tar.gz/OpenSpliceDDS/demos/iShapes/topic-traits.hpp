#ifndef _TOPIC_TRAITS_HPP
#define	_TOPIC_TRAITS_HPP

/** @file */
/**
 * @addtogroup demos_iShapes
 */
/** @{*/

#include "config.hpp"
#include "ishape_DCPS.hpp"


/** @}*/

#endif	/* _TOPIC_TRAITS_HPP */
